# Projet Game Master Go

## Sommaire
* [Description du projet](#description-du-projet)
* [Heuristique](#heuristique)
* [Spécificité](#specificité)
* [Début de partie](#debut-de-partie)
* [Alphago Zero](#alphago-zero)
* [Tests effectués](#test-effectues)


##  Description du projet

Le projet qui nous était proposé visait à réaliser une intelligence artificielle capable de jouer au Go. Pour ce faire nous devions mettre en place des algorithmes de recherche des meilleurs coups possibles à jouer.

## Heuristique

Dans la recherche de coup, la meilleure solution serait de générer tous les scénarios possibles. Cependant, réaliser cette action prendrait un temps beaucoup trop long. C'est pourquoi, une heuristique est nécessaire afin de limiter la profondeur de recherche de l'arbre. Nous avons choisi d'utiliser le réseau de neurone mis en place lors du TP de machine learning comme base pour créer notre heuristique. Nous n'avons pas pris exactement le même car nous avons trouvé un autre réseau légèrement plus fort. Celui-ci est un réseau qui estime une probabilité de victoire à chaque coup en connaissant l'état du plateau. Cette approche est un peu risquée, en effet un plateau possédant 80% de victoire pourrait quand même proposer un coup parmi l'ensemble des coups possibles à jouer qui amène à la défaite alors qu'un plateau évalué à 50% n'en propose pas forcement. Notre réseau n'est pas non plus parfait puisque parfois il peut se tromper et être certain de gagner alors que sa probabilité réelle est proche de 0 (heureusement c'est un cas plutôt rare).

Afin de rendre notre heuristique meilleure nous avons rajouté des tests sur les informations du plateau ("Est ce que le joueur rempli un des ses yeux ?", "Est ce qu'il prend des pions ?", "Est ce qu'il diminue ses libertés en dessous d'un seuil critique ?"). Ces ajouts nous on permis de limiter certains comportements que nous avons repérés au cours des parties (Remplir le plateau complètement en attendant que l'adversaire prenne tous nos pions)

## Spécificité

Nous avons quelques spécificités dans notre algorithme d'iterative deepening. Nous avons mis en place un système de file de priorité. En effet lors de la première couche nous parcourons les différents nœuds dans l'ordre dans lequel ils sont renvoyés par legal_moves. S'il reste du temps nous pouvons aller voir à une profondeur plus lointaine. Cependant si on suit l'ordre établi nous allons voir beaucoup de coup qui sont inutiles et nous allons perdre du temps. Ainsi nous avons mis en place, pour le premier niveau, un système qui permettait, le plus rapidement possible, de renvoyer les meilleurs coups que nous avions évalués dans l'ordre. Ainsi nous allons en priorité nous focaliser sur ces coups et s'il reste du temps nous parcourons le reste des coups. Nous ne jouons pas parfaitement, mais nous jouons optimalement sur les données vues. Nous nous sommes servis de PriorityQueue afin de réduire le plus possible le temps d'insertion et le temps d'accès à un élément de la pile des moves à voir.

Nous avons aussi mis en place un système permettant la gestion du temps alloué. Plus il y a de coups possibles plus le temps est court (parcourir tous les coups serait trop chronophage et peu utile puisque la valeur de l'heuristique serait peu précise pour si peu de coup). Cependant lorsqu'il y a très peu de pierre le temps diminue aussi (il y a de forte chance pour que beaucoup de pierre disparaissent et que l'on se retrouve ainsi dans un cas où il y a peu de pierre).

Nous avons aussi intégrer un peu d'aléatoire dans notre algorithme afin de ne pas jouer toujours les mêmes parties 


## AlphagoZero

Nous avons lors de se projet voulu implémenter l'algorithme utilisé par Google pour battre les plus grands champions. Cependant nous n'avons finalement pas réussi à l'entraîner. Le temps d'entraînement était incroyablement long (il aurait fallu que nous optimisions plus la partie jeu). Nous avons cependant construit la structure permettant l'entraînement en se basant sur le projet github de davidADSP, le lien se trouve tout en bas du README. Nous avons implémenté le fichier game.py et nous avons fait quelques modification sur les fichiers utilisant game.py. Nous allons maintenant expliquer le fonctionnement de l'algorithme. Celui-ci permet un apprentissage en partant de zéro. Il met en place plusieurs pans du machine learning. Il commence tout d'abord par générer des parties afin de récolter des statistiques sur celles-ci (nœuds amenant à une défaite, nombre de visites...). Cette génération de partie est réalisée à l'aide de l'algorithme de Monte Carlo Tree Search. Cet algorithme à l'avantage de dérouler une partie dans son ensemble puis de mettre à jour à l'aide d'un système de récompense les différentes données dont nous avions besoin. Ces données sont extrêmement utile dans la deuxième phase de notre algorithme, l'apprentissage d'un réseau de neurone profond.

Dans cette phase on vise à entraîner un réseau qui renvoie pour un plateau donné, une valeur à celui-ci et une probabilité d'estimation (sommes-nous sûr ou non de la valeur). Le réseau est composé de très nombreuses couches et reçoit en entrée un état composé de pas moins de 17 couches (représentant seulement les pierres du tableau, avec un historique ou des rotations de sorte qu'il n'y est aucune intervention humaine). Le réseau neuronal apprend ensuite sur les données capturées dans la phase précédente.

La dernière phase qui a lieu est dite phase de renforcement. On va prendre le champion actuel et le comparer avec le champion nouvellement entraîné. Pour ce faire on va les faire jouer l'un contre l'autre. Si le nouveau champion gagne dans plus de 55% des cas il devient la meilleure version. Afin d'avoir des parties variées qui permettent de bien représenter la force des algorithmes sur tout un éventail de possibilités, c'est là encore un algorithme de Monte Carlo qui est utilisé. Il permet de simuler plusieurs coups possibles tout en préservant "l'intelligence" de l'algorithme en favorisant les meilleurs coups évalués par les heuristiques.

L'algorithme utilise donc le Deep Reinforcement Learning pour apprendre.

## Début de partie

Nous avons préféré ne pas faire d'opening en se basant sur le json fourni. En effet nous avons remarqué qu'une profondeur 1 permettait en un temps très court (lorsque nous l'avons comparé aux autres c'était encore plus court chez nous) de renvoyer un coup tout à fait acceptable. Ainsi nous économisons du temps et nous renvoyons un bon coup.


## Tests effectués

Nous avons lancé plusieurs fois nos algorithmes. Nous avons testés sur des ordinateurs peu performants et nous avons eu des performances désastreuses. Cela s'explique par le fait que nous ne pouvons pas aller très loin dans la profondeur de l'arbre dans le temps alloué.
Cependant lorsque nous testons au CREMI nous avons des performances bien meilleures puisque nous pouvons aller plus loin dans l'arbre et prédire plus de coups en avance.

## Auteurs
BERTIN Clément
DUCHEMIN Emeric

##Lien utile
https://github.com/AppliedDataSciencePartners/DeepReinforcementLearning
Art.txt montrant un match entre notre algorithme et Lee Sedol =)
