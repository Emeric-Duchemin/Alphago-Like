#!/bin/bash

mkdir -p resultat

for file in `cat players.txt`
do
  mkdir -p resultat/$file
  rm -f resultat/$file/*.txt
  for adv in `cat players.txt`
  do
    TXT="../resultat/"$file"/"$adv
    cd src/ && python3 namedGame.py $file $adv 1> $TXT
    cd ../
  done
  echo "DONE"
done
